
export class User {
    FirstName: string;
    LastName: string;
    email: string;
    password: string;
    SpendLimit: string;
}