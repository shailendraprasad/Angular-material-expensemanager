var baseExpenseApiUrl = "http://localhost:3001/api/";

export { baseExpenseApiUrl }