export class Expense {
    amount: number;
    category: string;
    date: Date
}